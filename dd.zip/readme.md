# Data Visualization Project
 

Current Version: 0

Tasks done:
-
-


To do task list:
-
- 

Contributors:

- Rodrigo Guedes
- Beatriz Selidónio Gomes
- Catarina Garcez
